caer
====
AER event-based framework, written in C, targeting embedded systems.
